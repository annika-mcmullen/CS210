#include "Banking.h";
#include <iostream>;
#include <iomanip>;
using namespace std;

//This functions handles the calculations and output of when monthly deposit is not considered
void Banking :: displayTotalNoDeposit() {
	//Display cosmetic header
	cout << "*************************************************************" << endl;
	cout << "*          Banking Results with NO monthly deposit          *" << endl;
	cout << "*************************************************************" << endl;
	cout << "*               Closing Balance         Total Interest      *" << endl;

	totalMonthlyAmount = initialAmount;

	//outer loop calculates and stores the yearly interest for every 12 loops of the monthly inner loop
	for (int i = 0; i < years; i++) {
		//Set to 0 as no interest has accrued before first year
		yearlyInterestAmount = 0;
		//inner loop calculates the monthly values for one year
		for (int i = 0; i < 12; i++) {
			monthlyInterestAmount = (totalMonthlyAmount) * ((interestRate / 100) / 12);
			totalMonthlyAmount += monthlyInterestAmount;
			yearlyInterestAmount += monthlyInterestAmount;


		}

		//print statement showing the year, amount, and interest 
		cout << "Year: " << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalMonthlyAmount << "\t\t\t$" << yearlyInterestAmount << "\n";
	}

}

//This function handles the calculations and output of when monthly deposit is considered
void Banking :: displayTotalWithDeposit() {
	//cosmetic header
	cout << "*************************************************************" << endl;
	cout << "*          Banking Results with monthly deposit             *" << endl;
	cout << "*************************************************************" << endl;
	cout << "*               Closing Balance         Total Interest      *" << endl;

	totalMonthlyAmount = initialAmount + monthlyDeposit;
	//outer loop calculates and stores the yearly interest for every 12 loops of the monthly inner loop
	for (int i = 0; i < years; i++) {
		//Set to 0 as no interest has accrued before first year
		yearlyInterestAmount = 0;
		//inner loop calculates the monthly values for one year
		for (int j = 0; j < 12; j++) {
			monthlyInterestAmount = (totalMonthlyAmount + monthlyDeposit) * ((interestRate / 100) / 12);
			totalMonthlyAmount = monthlyInterestAmount + monthlyDeposit + totalMonthlyAmount; 
			yearlyInterestAmount += monthlyInterestAmount;


		}
		//print statement showing the year, amount, and interest
		cout <<"Year:" << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalMonthlyAmount << "\t\t\t$" << yearlyInterestAmount << "\n";
	}
}

//funciton displays user menu
void Banking::displayMenu() {
	cout << "************************" << endl;
	cout << "****User Information****" << endl;
	cout << "************************" << endl;
	cout << "*Initial Investment:   *" << endl;
	cout << "*Monthly Deposit:      *" << endl;
	cout << "*Interest Rate:        *" << endl;
	cout << "*Years:                *" << endl;
	cout << "************************" << endl;
}

//Function assigns user input to our data varaibles needed for calculations
int Banking::setValues() {
	bool isNumber = true;
	//Following makes sure user inputs correct data type and exits if not to avoid infinite loop
	try {
		cin >> initialAmount >> monthlyDeposit >> interestRate >> years;

		if (cin.fail()) {
			throw runtime_error("Not a valid input.");
		}
	}
	catch (runtime_error& excpt) {
		cout << excpt.what() << endl;
		cout << "Please only enter numbers" << endl;
		exit (EXIT_FAILURE);
	}
	}
	
