#include <iostream>;
#include <stdlib.h>;
#include "Banking.h";
#include <stdexcept>
using namespace std;

int main() {
	char userInput;
	//Declare an object of the Banking class
	Banking bankingUser;
	
		do {
			//Call functions of Banking class
			bankingUser.displayMenu();
			bankingUser.setValues();
			bankingUser.displayTotalNoDeposit();
			bankingUser.displayTotalWithDeposit();

			//Continue or break loop based on user input
			cout << "Would you like to try another example? (Y/N)" << endl;
			cin >> userInput;

			system("CLS"); //Clears screen after each loop for legibility of propgram
		} while ((userInput != 'N') && (userInput != 'n'));
}
