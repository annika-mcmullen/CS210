#pragma once

class Banking {
	//declare banking class attributes and functions
	public:
		double initialAmount;
		double monthlyDeposit;
		double years;
		double interestRate;
		void displayTotalNoDeposit();
		void displayTotalWithDeposit();
		void displayMenu(); 
		int setValues();

	//Following are private as they are only needed by Banking Class
	private:
		double monthlyInterestAmount;
		double yearlyInterestAmount;
		double totalMonthlyAmount;
		
		
		
};

